<?php date_default_timezone_set('Asia/Calcutta');
$conn=mysqli_connect('localhost','root','');
mysqli_select_db($conn,'task');
?>